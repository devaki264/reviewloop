# Authentic ReviewLoop captures

Captured from the live Streamlit application on 17 November 2026. Original viewport captures are in `originals`; presentation crops are in `crops`. Crops only remove surrounding UI: no content was generated, rewritten, or composited into the application.

- 01–07: five-character seeded demonstration, including Aster, Kite, Mirei, Obsidian and Sora. The app presents text briefs; there is no five-character artwork montage to capture.
- 08–11: rubric v1, accepted numerical rating under v1, rubric v2, and missing-justification failure under v2.
- 12–13: accepted weak justification and saved reviewer disagreement. The complete final decision is confirmed in the correction-history capture.
- 14–17: improvement-loop interface, two-cycle results, chart, and rubric history.

The slide table of all five characters is an editable transcription of observed results, not an app screenshot. Full captures preserve context; selected crops make evidence readable on slides. A synthetic reviewer override was entered during QA testing, not by an independent study participant.
